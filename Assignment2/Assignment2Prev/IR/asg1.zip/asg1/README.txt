LAUNCH:
  to launch the assignment we need to go to the directory eg. /asg1 in your terminal.
  run the command python3 assignment1.py
  it will launch the application

EXTERNAL LIBRARIES:
  os
  nltk
  numpy
  matplotlib
  collections
  sklearn

PYTHON VERSION:
  Python 3.11.5

TEAM MEMBERS:
  NAME: Balraj Hanmanthugari        UID: U01079536               EMAIL: hanmanthugari.2@wright.edu
  NAME: Deepika Kasula              UID: U01067608               EMAIL: kasula.16@wright.edu
  NAME: Nitish Kota                 UID: U01074656               EMAIL: kota.58@wright.edu